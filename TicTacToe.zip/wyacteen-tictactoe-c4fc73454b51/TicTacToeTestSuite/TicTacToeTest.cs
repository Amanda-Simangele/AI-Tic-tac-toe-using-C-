using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToeTestSuite
{
    using NUnit.Framework;
    using TicTacToe;
    [TestFixture]
    public class TicTacToeTest
    {

        
        


        public TicTacToeTest()
        {
            
        }

        [SetUp]
        public void Init()
        {

        }


        [TestFixture]
        public void TestMoves()
        {
            
        }
    }
}
